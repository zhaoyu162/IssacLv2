﻿namespace DZHClient
{
    internal class MethodInvoker
    {
        public MethodInvoker()
        {
        }
    }
}